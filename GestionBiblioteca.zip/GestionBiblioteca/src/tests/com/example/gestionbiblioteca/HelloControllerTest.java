package com.example.gestionbiblioteca;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class HelloControllerTest {

    
    @Test
    void altaLibro() {

    }

    @Test
    void menuAlta() {
    }

    @Test
    void bajaLibros() {
    }

    @Test
    void prestar() {
    }

    @Test
    void devolver() {
    }
}